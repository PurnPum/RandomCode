StartDebug()

local ABppmod = RegisterMod("AfterBirth++", 1)
local alphaMod
local SkinCancerId
local PC_HeartPurple 
local PC_HeartDarkRed 
local PC_HeartDarkBlue
local PC_HeartLightSalmon 
local PC_HeartLightBlue
local PC_HeartGrey 
local PC_HeartOrange 
local PC_HeartDarkGreen 
local PC_HeartDarkYellow
local PC_HeartLightYellow

local ITEMS = {}

local function start() 
	alphaMod = AlphaAPI.registerMod(ABppmod)
	
	PC_HeartPurple = alphaMod:getPickupConfig("Heart (Purple)", 1)
	PC_HeartDarkRed = alphaMod:getPickupConfig("Heart (Dark Red)", 2)
	PC_HeartDarkBlue = alphaMod:getPickupConfig("Heart (Dark Blue)", 3)
	PC_HeartLightSalmon = alphaMod:getPickupConfig("Heart (Light Salmon)", 4)
	PC_HeartLightBlue = alphaMod:getPickupConfig("Heart (Light Blue)", 5)
	PC_HeartGrey = alphaMod:getPickupConfig("Heart (Grey)", 6)
	PC_HeartOrange = alphaMod:getPickupConfig("Heart (Orange)", 7)
	PC_HeartDarkGreen = alphaMod:getPickupConfig("Heart (Dark Green)", 8)
	PC_HeartDarkYellow = alphaMod:getPickupConfig("Heart (Dark Yellow)", 9)
	PC_HeartLightYellow = alphaMod:getPickupConfig("Heart (Light Yellow)", 10)
	
	ITEMS.CJ = alphaMod:registerItem("Chemistry Jar", nil)
	ITEMS.CJ:addCallback(AlphaAPI.Callbacks.ENTITY_UPDATE, ABppmod.CJ_NormalHeartGrab, EntityType.ENTITY_PICKUP, PickupVariant.PICKUP_HEART)
	ITEMS.CJ:addCallback(AlphaAPI.Callbacks.ITEM_USE, ABppmod.ChemJar)
	ITEMS.CJ:addCallback(AlphaAPI.Callbacks.RUN_STARTED, ABppmod.CJ_Restart)
	ITEMS.CJ:addCallback(AlphaAPI.Callbacks.PICKUP_PICKUP, ABppmod.CJ_PickSpecialHeart, PC_HeartPurple)
	ITEMS.CJ:addCallback(AlphaAPI.Callbacks.PICKUP_PICKUP, ABppmod.CJ_PickSpecialHeart, PC_HeartDarkRed)
	ITEMS.CJ:addCallback(AlphaAPI.Callbacks.PICKUP_PICKUP, ABppmod.CJ_PickSpecialHeart, PC_HeartDarkBlue)
	ITEMS.CJ:addCallback(AlphaAPI.Callbacks.PICKUP_PICKUP, ABppmod.CJ_PickSpecialHeart, PC_HeartLightSalmon)
	ITEMS.CJ:addCallback(AlphaAPI.Callbacks.PICKUP_PICKUP, ABppmod.CJ_PickSpecialHeart, PC_HeartLightBlue)
	ITEMS.CJ:addCallback(AlphaAPI.Callbacks.PICKUP_PICKUP, ABppmod.CJ_PickSpecialHeart, PC_HeartGrey)
	ITEMS.CJ:addCallback(AlphaAPI.Callbacks.PICKUP_PICKUP, ABppmod.CJ_PickSpecialHeart, PC_HeartOrange)
	ITEMS.CJ:addCallback(AlphaAPI.Callbacks.PICKUP_PICKUP, ABppmod.CJ_PickSpecialHeart, PC_HeartDarkGreen)
	ITEMS.CJ:addCallback(AlphaAPI.Callbacks.PICKUP_PICKUP, ABppmod.CJ_PickSpecialHeart, PC_HeartDarkYellow)
	ITEMS.CJ:addCallback(AlphaAPI.Callbacks.PICKUP_PICKUP, ABppmod.CJ_PickSpecialHeart, PC_HeartLightYellow)
	ITEMS.CJ:addCallback(AlphaAPI.Callbacks.ENTITY_DAMAGE, ABppmod.CJ_LoseSpecialHeart, EntityType.ENTITY_PLAYER)

end

------------------------------------------------------------

-- Chemistry Jar --

local CJ_doVanishAnim = false

local CJ_tMainJar = {
	CoverState = false, -- Estado tapa , false : cerrado
	tHearts = {
		nil, -- Primer corazón
		nil	 -- Segundo corazón
		},
	CantHearts = 0 -- puede valer 0, 1 ó 2, también se usara para los estados de la jarra
}

local CJ_tPlayerSpHearts = {
	tHearts = {
		nil, -- Primer corazón
		nil, -- Segundo corazón
		nil	 -- Tercer corazón
		},
	CantHearts = 0 -- puede valer 0, 1, 2 ó 3
}

local CJ_tConfigs = {
		PC_HeartPurple,
		PC_HeartDarkRed,
		PC_HeartDarkBlue,
		PC_HeartLightSalmon,
		PC_HeartLightBlue,
		PC_HeartGrey,
		PC_HeartOrange,
		PC_HeartDarkGreen,
		PC_HeartDarkYellow,
		PC_HeartLightYellow
		}

local CJ_tAnimationNames = {
		"PurpleHeart",
		"DarkRedHeart",
		"DarkBlueHeart",
		"LightSalmonHeart",
		"LightBlueHeart",
		"GreyHeart",
		"OrangeHeart",
		"DarkGreenHeart",
		"DarkYellowHeart",
		"LightYellowHeart"
		}

local CJ_tSprites = {
	Sprite(),
	Sprite(),
	Sprite()
		}

function ABppmod:CJ_RenderHearts()
	local player = Isaac.GetPlayer(0)
	local ChemistryJar = Isaac.GetItemIdByName("Chemistry Jar")
	if player:HasCollectible(ChemistryJar) then
		CJ_tSprites[1]:Load("gfx/ui/ui_specialhearts.anm2",true)
		CJ_tSprites[2]:Load("gfx/ui/ui_specialhearts.anm2",true)
		CJ_tSprites[3]:Load("gfx/ui/ui_specialhearts.anm2",true)
		for i=1, 3 do -- Mira los 3 posibles corazones especiales del jugador
			if CJ_tPlayerSpHearts.tHearts[i] == nil then -- Si es nulo (está vacío)
				CJ_tSprites[i]:Play("EmptySpecialHeart",true) -- Pon el sprite de corazón vacío
			else
				for j=1, 10 do -- Ahora para los 10 posibles subtipos de corazones
					if CJ_tPlayerSpHearts.tHearts[i].SubType == j then -- Si el subtipo coincide con el almacenado
						CJ_tSprites[i]:Play(CJ_tAnimationNames[j],true) -- Reproduce la animación correspondiente de la tabla
						break -- Sal del for
					end
				end
			end
		end
		local v0 = Vector(0,0)
		CJ_tSprites[1]:Render(Vector(40,20),v0,v0) --TODO
		CJ_tSprites[2]:Render(Vector(56,20),v0,v0) --TODO
		CJ_tSprites[3]:Render(Vector(72,20),v0,v0) --TODO
	else
		CJ_tSprites[1]:Stop()
		CJ_tSprites[2]:Stop()
		CJ_tSprites[3]:Stop()
	end
end
	
function ABppmod.CJ_PickSpecialHeart(player,entity,data)
	Isaac.DebugString("func")
	for _,v in pairs(CJ_tConfigs) do
		Isaac.DebugString("for")
		if AlphaAPI.matchConfig(entity, v) then
			Isaac.DebugString("if matchconfig")
			if CJ_tPlayerSpHearts.CantHearts < 3 then
				Isaac.DebugString("if < 3")
				table.insert(CJ_tPlayerSpHearts.tHearts,entity)
				CJ_tPlayerSpHearts.CantHearts = CJ_tPlayerSpHearts.CantHearts + 1 
				return true
			end
		end
	end
end

ABppmod:AddCallback(ModCallbacks.MC_POST_RENDER, ABppmod.CJ_RenderHearts)
	

--[[function ABppmod:DebugText()
	debug_text = tostring(CJ_tMainJar.CoverState)
	debug_text2 = tostring(CJ_tMainJar.CantHearts)
	Isaac.RenderText(debug_text,100,100,255,0,0,255)
	Isaac.RenderText(debug_text2,100,120,255,0,0,255)
end

ABppmod:AddCallback(ModCallbacks.MC_POST_RENDER, ABppmod.DebugText)]]

-------------------
--  API Init
-------------------
local START_FUNC = start

if AlphaAPI then START_FUNC()
else if not __alphaInit then
    __alphaInit={} end __alphaInit
[#__alphaInit+1]=START_FUNC end